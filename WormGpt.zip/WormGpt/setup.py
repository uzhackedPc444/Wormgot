import os

print('install requests, rich, colorama, espeak')
os.system("pip install requests rich colorama; pkg install espeak -y")

